package com.example.android.common.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.android.bluetoothchat.MainActivity;
import com.example.android.bluetoothchat.R;
import com.example.android.common.logger.Log;

public class Login extends AppCompatActivity {

    EditText username, password;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username= (EditText) findViewById(R.id.username);
        password= (EditText) findViewById(R.id.password);
        login= (Button) findViewById(R.id.button);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user= username.getText().toString();
                String pass= password.getText().toString();
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Boolean voted= preferences.getBoolean(user, false);


                if (voted == true){

                    if (user.equals("user1") && pass.equals("user1pass")){
                        Intent values = new Intent(Login.this, MainActivity.class);
                        values.putExtra("USER_NAME",user);
                        startActivity(values);
                        // SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                        //   SharedPreferences.Editor editor = preferences.edit();
                        //   editor.putBoolean("Voted1",true);
                        //   editor.apply();
                        finish();
                    }


                if (user.equals("user2") && pass.equals("user2pass")){
                    Intent values = new Intent(Login.this, MainActivity.class);
                    values.putExtra("USER_NAME",user);
                    startActivity(values);
                    finish();
                }else {
                  //  Toast.makeText(Login.this, "Incorrect Login Details",Toast.LENGTH_SHORT).show();
                }
                if (user.equals("user3") && pass.equals("user3pass")){
                    Intent values = new Intent(Login.this, MainActivity.class);
                    values.putExtra("USER_NAME",user);
                    startActivity(values);
                    finish();
                }else {
                  //  Toast.makeText(Login.this, "Incorrect Login Details",Toast.LENGTH_SHORT).show();
                }
                if (user.equals("user4") && pass.equals("user4pass")){
                    Intent values = new Intent(Login.this, MainActivity.class);
                    values.putExtra("USER_NAME",user);
                    startActivity(values);
                    finish();
                }
                if (user.equals("user5") && pass.equals("user5pass")){
                    Intent values = new Intent(Login.this, MainActivity.class);
                    values.putExtra("USER_NAME",user);
                    startActivity(values);
                    finish();
                }else {
                 //   Toast.makeText(Login.this, "Incorrect Login Details",Toast.LENGTH_SHORT).show();
                }


                }else {
                    Toast.makeText(Login.this, "Already Voted",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}